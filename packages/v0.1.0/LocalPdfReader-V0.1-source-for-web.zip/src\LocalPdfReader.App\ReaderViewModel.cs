using System.ComponentModel;
using System.Collections.ObjectModel;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LocalPdfReader.App.Commands;
using LocalPdfReader.Application.PdfWorker;
using LocalPdfReader.Application.Reader;
using LocalPdfReader.Domain;

namespace LocalPdfReader.App;

public sealed class ReaderViewModel : INotifyPropertyChanged
{
    private const long MaximumCachedBitmapBytes = 64L * 1024 * 1024;
    private const double SelectionDragThreshold = 4;

    private readonly IPdfWorkerClient _pdfWorkerClient;
    private readonly ReaderState _readerState;
    private readonly ICoordinateTransformer _coordinateTransformer;
    private readonly TextSelectionService _textSelectionService;
    private readonly IUserErrorService _userErrorService;
    private readonly PageRenderCache<CachedPageBitmap> _pageCache = new(capacity: 3);
    private readonly AsyncCommand[] _readerCommands;
    private ImageSource? _pageImage;
    private double _pageDisplayWidth;
    private double _pageDisplayHeight;
    private string _statusText = "请选择一个 PDF 文件。";
    private string _pageNumberText = string.Empty;
    private bool _isOpening;
    private int _activeRenderCount;
    private CancellationTokenSource? _viewportRenderCancellationSource;
    private readonly Dictionary<(DocumentId DocumentId, int PageIndex), PageTextData> _pageTextCache = [];
    private readonly LinkedList<(DocumentId DocumentId, int PageIndex)> _pageTextCacheOrder = [];
    private PageTextData? _selectionPageText;
    private TextSelection? _currentSelection;
    private int? _selectionStartCharacterIndex;
    private ViewPoint? _selectionStartViewPoint;
    private bool _isPointerSelecting;
    private bool _hasSelectionDragStarted;
    private bool _selectionChangedInCurrentGesture;
    private DateTime _lastSelectionUpdate = DateTime.MinValue;
    private CancellationTokenSource? _textSelectionCancellationSource;
    private bool _isWorkerAvailable = true;
    private string? _currentFilePath;

    public ReaderViewModel(
        IPdfWorkerClient pdfWorkerClient,
        ReaderState readerState,
        ICoordinateTransformer coordinateTransformer,
        TextSelectionService textSelectionService,
        TranslationPanelViewModel translation,
        IUserErrorService userErrorService)
    {
        _pdfWorkerClient = pdfWorkerClient;
        _readerState = readerState;
        _coordinateTransformer = coordinateTransformer;
        _textSelectionService = textSelectionService;
        _userErrorService = userErrorService;
        Translation = translation;

        PreviousPageCommand = new AsyncCommand(MoveToPreviousPageAsync, () => CanMoveToPreviousPage);
        NextPageCommand = new AsyncCommand(MoveToNextPageAsync, () => CanMoveToNextPage);
        GoToPageCommand = new AsyncCommand(GoToPageAsync, () => CanUseDocumentControls);
        ZoomOutCommand = new AsyncCommand(ZoomOutAsync, () => CanZoomOut);
        ZoomInCommand = new AsyncCommand(ZoomInAsync, () => CanZoomIn);
        FitPageCommand = new AsyncCommand(FitPageAsync, () => CanFitPage);
        FitWidthCommand = new AsyncCommand(FitWidthAsync, () => CanFitPage);
        RotateClockwiseCommand = new AsyncCommand(RotateClockwiseAsync, () => CanUseDocumentControls);
        CopySelectionCommand = new AsyncCommand(CopySelectionAsync, () => CurrentSelection is not null);
        CopyRawSelectionCommand = new AsyncCommand(CopyRawSelectionAsync, () => CurrentSelection is not null);
        _readerCommands =
        [
            (AsyncCommand)PreviousPageCommand,
            (AsyncCommand)NextPageCommand,
            (AsyncCommand)GoToPageCommand,
            (AsyncCommand)ZoomOutCommand,
            (AsyncCommand)ZoomInCommand,
            (AsyncCommand)FitPageCommand,
            (AsyncCommand)FitWidthCommand,
            (AsyncCommand)RotateClockwiseCommand,
            (AsyncCommand)CopySelectionCommand,
            (AsyncCommand)CopyRawSelectionCommand
        ];
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public event EventHandler<ReaderErrorEventArgs>? ErrorOccurred;

    public ICommand PreviousPageCommand { get; }

    public ICommand NextPageCommand { get; }

    public ICommand GoToPageCommand { get; }

    public ICommand ZoomOutCommand { get; }

    public ICommand ZoomInCommand { get; }

    public ICommand FitPageCommand { get; }

    public ICommand FitWidthCommand { get; }

    public ICommand RotateClockwiseCommand { get; }

    public ICommand CopySelectionCommand { get; }

    public ICommand CopyRawSelectionCommand { get; }

    public ObservableCollection<SelectionRectangleViewModel> SelectionRectangles { get; } = [];

    public TranslationPanelViewModel Translation { get; }

    public TextSelection? CurrentSelection
    {
        get => _currentSelection;
        private set
        {
            if (SetProperty(ref _currentSelection, value))
            {
                Translation.SetSourceText(value?.NormalizedText ?? string.Empty);
                OnPropertyChanged(nameof(HasSelection));
                RaiseCommandCanExecuteChanged();
            }
        }
    }

    public bool HasSelection => CurrentSelection is not null;

    public ImageSource? PageImage
    {
        get => _pageImage;
        private set
        {
            if (SetProperty(ref _pageImage, value))
            {
                _pageDisplayWidth = (value as BitmapSource)?.PixelWidth ?? 0;
                _pageDisplayHeight = (value as BitmapSource)?.PixelHeight ?? 0;
                OnPropertyChanged(nameof(PageDisplayWidth));
                OnPropertyChanged(nameof(PageDisplayHeight));
            }
        }
    }

    public double PageDisplayWidth => _pageDisplayWidth;

    public double PageDisplayHeight => _pageDisplayHeight;

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    public string PageNumberText
    {
        get => _pageNumberText;
        set => SetProperty(ref _pageNumberText, value);
    }

    public string PageCountText => HasDocument ? $"/ {_readerState.PageCount}" : "/ 0";

    public bool IsOpening
    {
        get => _isOpening;
        private set
        {
            if (SetProperty(ref _isOpening, value))
            {
                OnPropertyChanged(nameof(CanOpenDocument));
            }
        }
    }

    public bool IsRendering => _activeRenderCount > 0;

    public bool IsWorkerAvailable => _isWorkerAvailable;

    public bool CanOpenDocument => IsWorkerAvailable && !IsOpening;

    public bool HasDocument => _readerState.HasDocument;

    public bool CanUseDocumentControls => IsWorkerAvailable && HasDocument;

    public bool CanMoveToPreviousPage => IsWorkerAvailable && HasDocument && _readerState.CurrentPageIndex > 0;

    public bool CanMoveToNextPage => IsWorkerAvailable && HasDocument && _readerState.CurrentPageIndex < _readerState.PageCount - 1;

    public bool CanZoomOut => IsWorkerAvailable && HasDocument && _readerState.ZoomFactor > ReaderState.MinimumZoomFactor;

    public bool CanZoomIn => IsWorkerAvailable && HasDocument && _readerState.ZoomFactor < ReaderState.MaximumZoomFactor;

    public bool CanFitPage => IsWorkerAvailable && HasDocument && _readerState.CurrentPageSize is not null &&
        _readerState.ViewportWidth > 0 && _readerState.ViewportHeight > 0;

    public void HandleWorkerDisconnected(PdfWorkerDisconnectedEventArgs eventArgs)
    {
        ArgumentNullException.ThrowIfNull(eventArgs);

        if (!_isWorkerAvailable)
        {
            return;
        }

        _isWorkerAvailable = false;
        _viewportRenderCancellationSource?.Cancel();
        _textSelectionCancellationSource?.Cancel();
        StatusText = "PDF 工作进程已意外停止，当前文档暂时不可操作；翻译面板仍可继续使用。";
        OnPropertyChanged(nameof(IsWorkerAvailable));
        OnPropertyChanged(nameof(CanOpenDocument));
        NotifyReaderStateChanged();
    }

    public void HandleWorkerRestarting()
    {
        StatusText = "正在重新启动 PDF 工作进程…";
    }

    public void HandleWorkerRestarted()
    {
        if (HasDocument)
        {
            StatusText = "PDF 工作进程已重新启动；当前页面已保留，文档会话将在下一步恢复。";
            return;
        }

        SetWorkerAvailability(true);
        StatusText = "PDF 工作进程已重新启动，可以打开文档。";
    }

    public async Task RecoverDocumentAfterWorkerRestartAsync(CancellationToken cancellationToken)
    {
        if (!HasDocument || string.IsNullOrWhiteSpace(_currentFilePath))
        {
            HandleWorkerRestarted();
            return;
        }

        var previousDocument = _readerState.DocumentInfo!;
        var viewState = _readerState.CaptureViewState();
        StatusText = "正在恢复 PDF 文档会话…";

        try
        {
            var recoveredDocument = await _pdfWorkerClient.OpenDocumentAsync(
                _currentFilePath,
                password: null,
                cancellationToken);

            _pageCache.ClearDocument(previousDocument.DocumentId);
            _pageTextCache.Clear();
            _pageTextCacheOrder.Clear();
            ClearSelection(preserveTranslationContext: true);
            _readerState.Restore(recoveredDocument, viewState);
            SetWorkerAvailability(true);
            NotifyReaderStateChanged();
            await RenderCurrentPageAsync();
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            StatusText = "PDF 文档会话恢复已取消。";
        }
        catch (Exception exception)
        {
            var userError = _userErrorService.Report(UserErrorCode.DocumentRecoveryFailed, exception);
            _readerState.Close();
            _currentFilePath = null;
            ClearSelection(preserveTranslationContext: true);
            PageImage = null;
            SetWorkerAvailability(true);
            NotifyReaderStateChanged();
            StatusText = userError.InlineText;
        }
    }

    public void HandleWorkerRestartFailed(UserFacingError error)
    {
        ArgumentNullException.ThrowIfNull(error);
        StatusText = error.InlineText;
    }

    private void SetWorkerAvailability(bool isAvailable)
    {
        if (_isWorkerAvailable == isAvailable)
        {
            return;
        }

        _isWorkerAvailable = isAvailable;
        OnPropertyChanged(nameof(IsWorkerAvailable));
        OnPropertyChanged(nameof(CanOpenDocument));
        NotifyReaderStateChanged();
    }

    public void UpdateViewportSize(double width, double height)
    {
        var zoomChanged = _readerState.UpdateViewportSize(width, height);
        NotifyFitStateChanged();

        if (!zoomChanged || !IsWorkerAvailable)
        {
            return;
        }

        NotifyReaderStateChanged();
        _viewportRenderCancellationSource?.Cancel();
        _viewportRenderCancellationSource?.Dispose();
        _viewportRenderCancellationSource = new CancellationTokenSource();
        _ = RenderAfterViewportChangeAsync(_viewportRenderCancellationSource.Token);
    }

    public async Task OpenDocumentAsync(string filePath, CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(filePath);

        if (!IsWorkerAvailable)
        {
            StatusText = "PDF 工作进程当前不可用，暂时无法打开文档。";
            return;
        }

        IsOpening = true;
        StatusText = "正在由 PDF Worker 打开并渲染第一页…";

        try
        {
            if (_readerState.DocumentInfo is { } previousDocument)
            {
                _pageCache.ClearDocument(previousDocument.DocumentId);
                _pageTextCache.Clear();
                _pageTextCacheOrder.Clear();
                ClearSelection();
                _readerState.Close();
                _currentFilePath = null;
                NotifyReaderStateChanged();
                PageImage = null;
                await _pdfWorkerClient.CloseDocumentAsync(previousDocument.DocumentId, cancellationToken);
            }

            var documentInfo = await _pdfWorkerClient.OpenDocumentAsync(filePath, password: null, cancellationToken);
            _readerState.Open(documentInfo);
            _currentFilePath = Path.GetFullPath(filePath);
            NotifyReaderStateChanged();
            await RenderCurrentPageAsync();
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            StatusText = "已取消打开 PDF。";
        }
        catch (Exception exception)
        {
            var userError = _userErrorService.Report(UserErrorCode.DocumentOpenFailed, exception);
            StatusText = userError.InlineText;
            ErrorOccurred?.Invoke(this, new ReaderErrorEventArgs(userError));
        }
        finally
        {
            IsOpening = false;
        }
    }

    public async Task BeginSelectionAsync(ViewPoint viewPoint, CancellationToken cancellationToken)
    {
        _isPointerSelecting = true;
        CancelTextSelectionRequest();
        _selectionPageText = null;
        _selectionStartCharacterIndex = null;
        _selectionStartViewPoint = null;
        _hasSelectionDragStarted = false;
        _selectionChangedInCurrentGesture = false;
        _lastSelectionUpdate = DateTime.MinValue;
        _textSelectionCancellationSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var selectionCancellationToken = _textSelectionCancellationSource.Token;

        if (_readerState.DocumentInfo is not { } documentInfo || _readerState.CurrentPageSize is null)
        {
            return;
        }

        var pageIndex = _readerState.CurrentPageIndex;
        StatusText = "正在读取页面文字…";

        try
        {
            var pageText = await GetPageTextAsync(documentInfo.DocumentId, pageIndex, selectionCancellationToken);
            if (!_isPointerSelecting ||
                _readerState.DocumentInfo?.DocumentId != documentInfo.DocumentId ||
                _readerState.CurrentPageIndex != pageIndex)
            {
                return;
            }

            _selectionPageText = pageText;
            var hit = HitTestSelection(viewPoint);
            if (hit is null)
            {
                StatusText = CurrentSelection is not null
                    ? "未点中文字，已保留原选区和翻译内容。"
                    : pageText.Glyphs.Count == 0
                        ? "当前页面没有可选择文字层。"
                        : "请从文字上开始拖动选择。";
                return;
            }

            _selectionStartCharacterIndex = hit.CharacterIndex;
            _selectionStartViewPoint = viewPoint;
            StatusText = "已定位文字起点，请拖动鼠标以选择文本。";
        }
        catch (OperationCanceledException) when (selectionCancellationToken.IsCancellationRequested)
        {
        }
        catch (Exception exception)
        {
            var userError = _userErrorService.Report(UserErrorCode.TextExtractionFailed, exception);
            StatusText = userError.InlineText;
            ErrorOccurred?.Invoke(this, new ReaderErrorEventArgs(userError));
        }
    }

    public void UpdateSelection(ViewPoint viewPoint)
    {
        if (!_isPointerSelecting || _selectionStartCharacterIndex is null)
        {
            return;
        }

        if (!_hasSelectionDragStarted)
        {
            if (_selectionStartViewPoint is not { } startViewPoint)
            {
                return;
            }

            var deltaX = viewPoint.X - startViewPoint.X;
            var deltaY = viewPoint.Y - startViewPoint.Y;
            if (deltaX * deltaX + deltaY * deltaY < SelectionDragThreshold * SelectionDragThreshold)
            {
                return;
            }

            _hasSelectionDragStarted = true;
        }

        var now = DateTime.UtcNow;
        if (now - _lastSelectionUpdate < TimeSpan.FromMilliseconds(20))
        {
            return;
        }

        _lastSelectionUpdate = now;
        var hit = HitTestSelection(viewPoint);
        if (hit is not null)
        {
            UpdateCurrentSelection(hit.CharacterIndex);
            _selectionChangedInCurrentGesture = true;
        }
    }

    public void CompleteSelection()
    {
        _isPointerSelecting = false;
        if (_selectionStartCharacterIndex is null || !_selectionChangedInCurrentGesture)
        {
            CancelTextSelectionRequest();
            if (CurrentSelection is not null)
            {
                StatusText = "未拖动选择文字，已保留原选区和翻译内容。";
            }
            else if (_selectionStartCharacterIndex is not null)
            {
                StatusText = "请按住鼠标并拖动以选择文字。";
            }

            return;
        }

        if (CurrentSelection is not null)
        {
            StatusText = $"已选择 {CurrentSelection.NormalizedText.Length} 个字符，可复制或在右侧手动开始翻译。";
        }
    }

    private Task MoveToPreviousPageAsync() => ChangePageAndRenderAsync(_readerState.MoveToPreviousPage);

    private Task MoveToNextPageAsync() => ChangePageAndRenderAsync(_readerState.MoveToNextPage);

    private async Task GoToPageAsync()
    {
        if (!int.TryParse(PageNumberText, out var pageNumber) ||
            pageNumber < 1 ||
            pageNumber > _readerState.PageCount)
        {
            PageNumberText = _readerState.CurrentPageNumber.ToString();
            StatusText = $"请输入 1 至 {_readerState.PageCount} 之间的页码。";
            return;
        }

        if (!_readerState.SetPageNumber(pageNumber))
        {
            PageNumberText = _readerState.CurrentPageNumber.ToString();
            return;
        }

        ClearSelection();
        NotifyReaderStateChanged();
        await RenderCurrentPageAsync();
    }

    private Task ZoomOutAsync() => ChangeReaderStateAndRenderAsync(_readerState.ZoomOut);

    private Task ZoomInAsync() => ChangeReaderStateAndRenderAsync(_readerState.ZoomIn);

    private Task FitPageAsync() => ChangeReaderStateAndRenderAsync(_readerState.FitPage);

    private Task FitWidthAsync() => ChangeReaderStateAndRenderAsync(_readerState.FitWidth);

    private Task RotateClockwiseAsync() => ChangeReaderStateAndRenderAsync(_readerState.RotateClockwise);

    private async Task ChangePageAndRenderAsync(Func<bool> changePage)
    {
        if (!changePage())
        {
            return;
        }

        ClearSelection();
        NotifyReaderStateChanged();
        await RenderCurrentPageAsync();
    }

    private async Task ChangeReaderStateAndRenderAsync(Func<bool> changeState)
    {
        if (!changeState())
        {
            return;
        }

        NotifyReaderStateChanged();
        await RenderCurrentPageAsync();
    }

    private async Task RenderCurrentPageAsync()
    {
        if (_readerState.DocumentInfo is not { } documentInfo)
        {
            return;
        }

        var renderGeneration = _readerState.RenderGeneration;
        var request = new PageRenderRequest(
            Guid.NewGuid(),
            documentInfo.DocumentId,
            _readerState.CurrentPageIndex,
            _readerState.ZoomFactor,
            _readerState.Rotation,
            1,
            1,
            RenderQuality.Normal);
        var cacheKey = new PageRenderCacheKey(
            request.DocumentId,
            request.PageIndex,
            request.ZoomFactor,
            request.Rotation,
            request.DpiScaleX,
            request.DpiScaleY,
            request.Quality);

        if (_pageCache.TryGet(cacheKey, out var cachedPage) && cachedPage is not null)
        {
            var shouldRerenderForFit = _readerState.SetCurrentPageSize(cachedPage.OriginalPageSize);
            NotifyFitStateChanged();

            if (shouldRerenderForFit)
            {
                NotifyReaderStateChanged();
                await RenderCurrentPageAsync();
                return;
            }

            if (_readerState.IsLatestRender(renderGeneration))
            {
                PageImage = cachedPage.Bitmap;
                SetReadyStatus(documentInfo, isCached: true);
                RebuildSelectionRectangles();
            }

            return;
        }

        SetRendering(true);
        StatusText = "正在渲染页面…";

        try
        {
            var descriptor = await _pdfWorkerClient.RenderPageAsync(request, CancellationToken.None);
            var shouldRerenderForFit = false;
            try
            {
                if (!_readerState.IsLatestRender(renderGeneration) || descriptor.RequestId != request.RequestId)
                {
                    return;
                }

                shouldRerenderForFit = _readerState.SetCurrentPageSize(descriptor.OriginalPageSize);
                NotifyFitStateChanged();

                if (!shouldRerenderForFit)
                {
                    var bitmap = ReadBitmap(descriptor);
                    if (!_readerState.IsLatestRender(renderGeneration))
                    {
                        return;
                    }

                    if (descriptor.DataLength <= MaximumCachedBitmapBytes)
                    {
                        _pageCache.Set(cacheKey, new CachedPageBitmap(bitmap, descriptor.OriginalPageSize));
                    }
                    PageImage = bitmap;
                    SetReadyStatus(documentInfo, isCached: false);
                    RebuildSelectionRectangles();
                }
            }
            finally
            {
                // Whether displayed or discarded, every worker-owned mapping receives an explicit release acknowledgement.
                await _pdfWorkerClient.ReleaseSharedMemoryAsync(descriptor.MemoryMapName, CancellationToken.None);
            }

            if (shouldRerenderForFit)
            {
                NotifyReaderStateChanged();
                await RenderCurrentPageAsync();
            }
        }
        catch (Exception exception)
        {
            if (_readerState.IsLatestRender(renderGeneration))
            {
                var userError = _userErrorService.Report(UserErrorCode.PageRenderFailed, exception);
                StatusText = userError.InlineText;
                ErrorOccurred?.Invoke(this, new ReaderErrorEventArgs(userError));
            }
        }
        finally
        {
            SetRendering(false);
        }
    }

    private void NotifyReaderStateChanged()
    {
        PageNumberText = HasDocument ? _readerState.CurrentPageNumber.ToString() : string.Empty;
        OnPropertyChanged(nameof(HasDocument));
        OnPropertyChanged(nameof(CanUseDocumentControls));
        OnPropertyChanged(nameof(PageCountText));
        OnPropertyChanged(nameof(CanMoveToPreviousPage));
        OnPropertyChanged(nameof(CanMoveToNextPage));
        OnPropertyChanged(nameof(CanZoomOut));
        OnPropertyChanged(nameof(CanZoomIn));
        OnPropertyChanged(nameof(CanFitPage));

        foreach (var command in _readerCommands)
        {
            command.RaiseCanExecuteChanged();
        }
    }

    private void NotifyFitStateChanged()
    {
        OnPropertyChanged(nameof(CanFitPage));

        foreach (var command in _readerCommands)
        {
            command.RaiseCanExecuteChanged();
        }
    }

    private async Task<PageTextData> GetPageTextAsync(
        DocumentId documentId,
        int pageIndex,
        CancellationToken cancellationToken)
    {
        var key = (documentId, pageIndex);
        if (_pageTextCache.TryGetValue(key, out var cached))
        {
            TouchPageTextCache(key);
            return cached;
        }

        var pageText = await _pdfWorkerClient.GetPageTextAsync(documentId, pageIndex, cancellationToken);
        _pageTextCache[key] = pageText;
        TouchPageTextCache(key);
        while (_pageTextCacheOrder.Count > 3)
        {
            var oldest = _pageTextCacheOrder.Last!.Value;
            _pageTextCacheOrder.RemoveLast();
            _pageTextCache.Remove(oldest);
        }

        return pageText;
    }

    private void TouchPageTextCache((DocumentId DocumentId, int PageIndex) key)
    {
        var existing = _pageTextCacheOrder.Find(key);
        if (existing is not null)
        {
            _pageTextCacheOrder.Remove(existing);
        }

        _pageTextCacheOrder.AddFirst(key);
    }

    private TextGlyph? HitTestSelection(ViewPoint viewPoint)
    {
        if (_selectionPageText is null || _readerState.CurrentPageSize is null)
        {
            return null;
        }

        var context = CreateTransformContext();
        var pdfPoint = _coordinateTransformer.ViewToPdf(viewPoint, context);
        var pdfTolerance = 5 / (Math.Max(ReaderState.MinimumZoomFactor, _readerState.ZoomFactor) * 96d / 72d);
        return _textSelectionService.HitTest(_selectionPageText, pdfPoint, pdfTolerance);
    }

    private void UpdateCurrentSelection(int endCharacterIndex)
    {
        if (_selectionPageText is null || _selectionStartCharacterIndex is not { } startCharacterIndex)
        {
            return;
        }

        CurrentSelection = _textSelectionService.CreateSelection(
            _selectionPageText,
            startCharacterIndex,
            endCharacterIndex);
        RebuildSelectionRectangles();
    }

    private void RebuildSelectionRectangles()
    {
        SelectionRectangles.Clear();
        if (CurrentSelection is not { } selection ||
            _readerState.DocumentInfo?.DocumentId != selection.DocumentId ||
            _readerState.CurrentPageIndex != selection.PageIndex ||
            _readerState.CurrentPageSize is null)
        {
            return;
        }

        var context = CreateTransformContext();
        foreach (var rectangle in selection.HighlightRectangles)
        {
            var viewRectangle = _coordinateTransformer.PdfToView(rectangle, context);
            SelectionRectangles.Add(new SelectionRectangleViewModel(
                viewRectangle.X,
                viewRectangle.Y,
                viewRectangle.Width,
                viewRectangle.Height));
        }
    }

    private PageTransformContext CreateTransformContext()
    {
        var pageSize = _readerState.CurrentPageSize!.Value;
        var isQuarterTurn = _readerState.Rotation is PageRotation.Rotate90 or PageRotation.Rotate270;
        var rotatedWidth = isQuarterTurn ? pageSize.Height : pageSize.Width;
        var rotatedHeight = isQuarterTurn ? pageSize.Width : pageSize.Height;
        var baseScale = _readerState.ZoomFactor * 96d / 72d;

        // PDFium rounds target bitmap dimensions to whole pixels. Deriving the effective DPI scales
        // from the displayed bitmap keeps selection coordinates aligned with that exact rounding.
        var effectiveDpiScaleX = PageDisplayWidth > 0
            ? PageDisplayWidth / (rotatedWidth * baseScale)
            : 1;
        var effectiveDpiScaleY = PageDisplayHeight > 0
            ? PageDisplayHeight / (rotatedHeight * baseScale)
            : 1;

        return new PageTransformContext(
            pageSize,
            _readerState.ZoomFactor,
            _readerState.Rotation,
            effectiveDpiScaleX,
            effectiveDpiScaleY,
            PageOffsetX: 0,
            PageOffsetY: 0);
    }

    private Task CopySelectionAsync()
    {
        if (CurrentSelection is null)
        {
            return Task.CompletedTask;
        }

        try
        {
            System.Windows.Clipboard.SetText(CurrentSelection.NormalizedText);
            StatusText = "已复制规范化文字。";
        }
        catch (Exception exception)
        {
            var userError = _userErrorService.Report(UserErrorCode.ClipboardWriteFailed, exception);
            StatusText = userError.InlineText;
            ErrorOccurred?.Invoke(this, new ReaderErrorEventArgs(userError));
        }

        return Task.CompletedTask;
    }

    private Task CopyRawSelectionAsync()
    {
        if (CurrentSelection is null)
        {
            return Task.CompletedTask;
        }

        try
        {
            System.Windows.Clipboard.SetText(CurrentSelection.RawText);
            StatusText = "已复制 PDF 原始提取文字。";
        }
        catch (Exception exception)
        {
            var userError = _userErrorService.Report(UserErrorCode.ClipboardWriteFailed, exception);
            StatusText = userError.InlineText;
            ErrorOccurred?.Invoke(this, new ReaderErrorEventArgs(userError));
        }

        return Task.CompletedTask;
    }

    private void ClearSelection(
        bool keepPointerSelecting = false,
        bool preserveTranslationContext = false)
    {
        CancelTextSelectionRequest();
        if (!keepPointerSelecting)
        {
            _isPointerSelecting = false;
        }

        _selectionPageText = null;
        _selectionStartCharacterIndex = null;
        _selectionStartViewPoint = null;
        _hasSelectionDragStarted = false;
        _selectionChangedInCurrentGesture = false;
        if (preserveTranslationContext)
        {
            if (SetProperty(ref _currentSelection, null, nameof(CurrentSelection)))
            {
                OnPropertyChanged(nameof(HasSelection));
                RaiseCommandCanExecuteChanged();
            }
        }
        else
        {
            CurrentSelection = null;
        }
        SelectionRectangles.Clear();
    }

    private void CancelTextSelectionRequest()
    {
        _textSelectionCancellationSource?.Cancel();
        _textSelectionCancellationSource?.Dispose();
        _textSelectionCancellationSource = null;
    }

    private async Task RenderAfterViewportChangeAsync(CancellationToken cancellationToken)
    {
        try
        {
            await Task.Delay(TimeSpan.FromMilliseconds(150), cancellationToken);
            await RenderCurrentPageAsync();
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
        }
    }

    private void SetReadyStatus(PdfDocumentInfo documentInfo, bool isCached)
    {
        var cacheStatus = isCached ? "，来自内存缓存" : string.Empty;
        StatusText = $"{documentInfo.FileName}：第 {_readerState.CurrentPageNumber}/{_readerState.PageCount} 页，缩放 {_readerState.ZoomFactor:P0}，旋转 {(int)_readerState.Rotation}°{cacheStatus}。";
    }

    private void SetRendering(bool isStarting)
    {
        var wasRendering = IsRendering;
        _activeRenderCount += isStarting ? 1 : -1;

        if (wasRendering != IsRendering)
        {
            OnPropertyChanged(nameof(IsRendering));
        }
    }

    private static BitmapSource ReadBitmap(RenderedPageDescriptor descriptor)
    {
        if (descriptor.PixelFormat != "BGRA32")
        {
            throw new InvalidDataException($"Unsupported pixel format {descriptor.PixelFormat}.");
        }

        if (descriptor.DataLength != (long)descriptor.Stride * descriptor.PixelHeight)
        {
            throw new InvalidDataException("The shared bitmap size does not match its dimensions.");
        }

        using var memoryMap = MemoryMappedFile.OpenExisting(descriptor.MemoryMapName, MemoryMappedFileRights.Read);
        using var view = memoryMap.CreateViewAccessor(0, descriptor.DataLength, MemoryMappedFileAccess.Read);
        var pixels = new byte[checked((int)descriptor.DataLength)];
        view.ReadArray(0, pixels, 0, pixels.Length);

        var bitmap = BitmapSource.Create(
            descriptor.PixelWidth,
            descriptor.PixelHeight,
            96,
            96,
            PixelFormats.Bgra32,
            palette: null,
            pixels,
            descriptor.Stride);
        bitmap.Freeze();
        return bitmap;
    }

    private bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }

        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

    private void RaiseCommandCanExecuteChanged()
    {
        foreach (var command in _readerCommands)
        {
            command.RaiseCanExecuteChanged();
        }
    }

    private sealed record CachedPageBitmap(BitmapSource Bitmap, PdfSize OriginalPageSize);
}

public sealed record SelectionRectangleViewModel(double X, double Y, double Width, double Height);

public sealed class ReaderErrorEventArgs(UserFacingError error) : EventArgs
{
    public UserFacingError Error { get; } = error;
}
