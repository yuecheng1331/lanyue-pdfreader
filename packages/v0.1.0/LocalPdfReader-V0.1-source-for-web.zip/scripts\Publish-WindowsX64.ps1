[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$repositoryRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$artifactsRoot = [System.IO.Path]::GetFullPath((Join-Path $repositoryRoot 'artifacts'))
$publishDirectory = [System.IO.Path]::GetFullPath((Join-Path $artifactsRoot 'publish\win-x64'))
$archivePath = [System.IO.Path]::GetFullPath((Join-Path $artifactsRoot 'LocalPdfReader-win-x64.zip'))
$expectedPrefix = $artifactsRoot.TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar

if (-not $publishDirectory.StartsWith($expectedPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to clean a publish path outside the artifacts directory: $publishDirectory"
}

if (Test-Path -LiteralPath $publishDirectory) {
    Remove-Item -LiteralPath $publishDirectory -Recurse -Force
}

if (Test-Path -LiteralPath $archivePath) {
    Remove-Item -LiteralPath $archivePath -Force
}

$projectPath = Join-Path $repositoryRoot 'src\LocalPdfReader.App\LocalPdfReader.App.csproj'
& dotnet publish $projectPath -c Release -p:PublishProfile=WindowsX64
if ($LASTEXITCODE -ne 0) {
    throw "Windows x64 publish failed with exit code $LASTEXITCODE."
}

$requiredFiles = @(
    'LocalPdfReader.App.exe',
    'LocalPdfReader.PdfWorker.exe',
    'LocalPdfReader.App.runtimeconfig.json',
    'LocalPdfReader.PdfWorker.runtimeconfig.json',
    'hostfxr.dll',
    'pdfium.dll'
)

foreach ($relativePath in $requiredFiles) {
    $fullPath = Join-Path $publishDirectory $relativePath
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        throw "The publish package is missing required file: $relativePath"
    }
}

$forbiddenNames = @(
    '*.key',
    '*.pfx',
    '*.secrets.json',
    'secrets.json',
    'LocalPdfReader.settings.json',
    'settings.local.json',
    'appsettings.Local.json',
    '*.log'
)

$forbiddenFiles = foreach ($pattern in $forbiddenNames) {
    Get-ChildItem -LiteralPath $publishDirectory -Recurse -File -Filter $pattern
}

if ($forbiddenFiles) {
    $names = ($forbiddenFiles.FullName | Sort-Object -Unique) -join [Environment]::NewLine
    throw "The publish package contains forbidden local settings, secrets, or logs:$([Environment]::NewLine)$names"
}

Compress-Archive -Path (Join-Path $publishDirectory '*') -DestinationPath $archivePath -CompressionLevel Optimal

$archiveHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash
$archiveSizeMiB = [Math]::Round((Get-Item -LiteralPath $archivePath).Length / 1MB, 2)

Write-Host "Publish package: $archivePath"
Write-Host "Size: $archiveSizeMiB MiB"
Write-Host "SHA256: $archiveHash"
