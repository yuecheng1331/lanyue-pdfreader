namespace LocalPdfReader.Application.Configuration;

public sealed record AppSettings
{
    public int SchemaVersion { get; init; } = 1;

    public TranslationSettings Translation { get; init; } = new();

    public ReaderSettings Reader { get; init; } = new();

    public PrivacySettings Privacy { get; init; } = new();

    public DiagnosticsSettings Diagnostics { get; init; } = new();
}

public sealed record TranslationSettings
{
    public string Provider { get; init; } = "DeepSeek";

    public string BaseUrl { get; init; } = "https://api.deepseek.com";

    public string Model { get; init; } = "deepseek-chat";

    public string TargetLanguage { get; init; } = "zh-CN";

    public string DefaultPreset { get; init; } = "Academic";

    public int TimeoutSeconds { get; init; } = 60;

    public bool Stream { get; init; } = true;
}

public sealed record ReaderSettings
{
    public string DefaultZoomMode { get; init; } = "FitWidth";

    public double MinimumZoom { get; init; } = 0.1;

    public double MaximumZoom { get; init; } = 8.0;

    public bool RememberLastFile { get; init; }
}

public sealed record PrivacySettings
{
    public bool AllowTranslationNetworkAccess { get; init; } = true;

    public bool LogSourceText { get; init; }
}

public sealed record DiagnosticsSettings
{
    public string LogLevel { get; init; } = "Information";
}
