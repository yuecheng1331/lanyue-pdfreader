using System.Collections.Concurrent;
using System.IO.MemoryMappedFiles;
using LocalPdfReader.Domain;

namespace LocalPdfReader.PdfWorker;

internal sealed class WorkerDocumentService(IPdfNativeAdapter nativeAdapter) : IDisposable
{
    private readonly ConcurrentDictionary<DocumentId, NativePdfDocument> _documents = new();
    private readonly ConcurrentDictionary<string, MemoryMappedFile> _sharedMemory = new(StringComparer.Ordinal);
    private bool _disposed;

    public PdfDocumentInfo Open(string filePath, string? password)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException("The PDF file does not exist.", filePath);
        }

        var nativeDocument = nativeAdapter.Open(filePath, password);
        var documentId = new DocumentId(Guid.NewGuid());

        try
        {
            var info = nativeAdapter.GetDocumentInfo(nativeDocument, documentId, Path.GetFileName(filePath)).DocumentInfo;
            if (info.PageCount <= 0)
            {
                throw new InvalidDataException("The PDF does not contain any pages.");
            }

            if (!_documents.TryAdd(documentId, nativeDocument))
            {
                throw new InvalidOperationException("The PDF document identifier is already in use.");
            }

            return info;
        }
        catch
        {
            nativeAdapter.Close(nativeDocument);
            throw;
        }
    }

    public void Close(DocumentId documentId)
    {
        if (_documents.TryRemove(documentId, out var nativeDocument))
        {
            nativeAdapter.Close(nativeDocument);
        }
    }

    public RenderedPageDescriptor Render(PageRenderRequest request)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        if (!_documents.TryGetValue(request.DocumentId, out var nativeDocument))
        {
            throw new InvalidOperationException("The requested PDF document is not open.");
        }

        var renderedPage = nativeAdapter.RenderPage(nativeDocument, request);
        var memoryMapName = $"LocalPdfReader.Bitmap.{Environment.ProcessId}.{request.RequestId:N}";
        var memoryMap = MemoryMappedFile.CreateNew(memoryMapName, renderedPage.Pixels.LongLength, MemoryMappedFileAccess.ReadWrite);

        try
        {
            using (var view = memoryMap.CreateViewAccessor(0, renderedPage.Pixels.LongLength, MemoryMappedFileAccess.Write))
            {
                view.WriteArray(0, renderedPage.Pixels, 0, renderedPage.Pixels.Length);
            }

            if (!_sharedMemory.TryAdd(memoryMapName, memoryMap))
            {
                throw new InvalidOperationException("The rendered page memory map name is already in use.");
            }

            return new RenderedPageDescriptor(
                request.RequestId,
                request.DocumentId,
                request.PageIndex,
                renderedPage.PixelWidth,
                renderedPage.PixelHeight,
                renderedPage.Stride,
                "BGRA32",
                memoryMapName,
                renderedPage.Pixels.LongLength,
                renderedPage.OriginalPageSize);
        }
        catch
        {
            memoryMap.Dispose();
            throw;
        }
    }

    public PageTextData GetPageText(DocumentId documentId, int pageIndex)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (!_documents.TryGetValue(documentId, out var nativeDocument))
        {
            throw new InvalidOperationException("The requested PDF document is not open.");
        }

        return nativeAdapter.ExtractPageText(nativeDocument, documentId, pageIndex);
    }

    public TextHitTestResult? HitTestText(
        DocumentId documentId,
        int pageIndex,
        PdfPoint point,
        double tolerance)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (!_documents.TryGetValue(documentId, out var nativeDocument))
        {
            throw new InvalidOperationException("The requested PDF document is not open.");
        }

        return nativeAdapter.HitTestText(nativeDocument, pageIndex, point, tolerance);
    }

    public bool ReleaseSharedMemory(string memoryMapName)
    {
        if (!_sharedMemory.TryRemove(memoryMapName, out var memoryMap))
        {
            return false;
        }

        memoryMap.Dispose();
        return true;
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        foreach (var documentId in _documents.Keys)
        {
            Close(documentId);
        }

        foreach (var memoryMapName in _sharedMemory.Keys)
        {
            ReleaseSharedMemory(memoryMapName);
        }

        nativeAdapter.Dispose();
    }
}
