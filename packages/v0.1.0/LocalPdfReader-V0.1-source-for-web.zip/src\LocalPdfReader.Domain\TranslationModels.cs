namespace LocalPdfReader.Domain;

public sealed record TranslationRequest(
    Guid RequestId,
    string SourceText,
    string TargetLanguage,
    TranslationPreset Preset,
    string? SourceLanguage = null,
    string? CustomInstruction = null);

public sealed record TranslationChunk(
    Guid RequestId,
    string Text,
    bool IsCompleted);

public enum TranslationPreset
{
    Literal,
    Fluent,
    Academic,
    ComputerScience,
    Medical,
    Custom
}
