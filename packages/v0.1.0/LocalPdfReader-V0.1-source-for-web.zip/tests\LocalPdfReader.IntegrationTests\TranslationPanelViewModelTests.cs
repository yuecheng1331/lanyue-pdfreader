using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using LocalPdfReader.App;
using LocalPdfReader.Application.Configuration;
using LocalPdfReader.Application.PdfWorker;
using LocalPdfReader.Application.Reader;
using LocalPdfReader.Application.Translation;
using LocalPdfReader.Domain;
using Microsoft.Extensions.Logging.Abstractions;

namespace LocalPdfReader.IntegrationTests;

public class TranslationPanelViewModelTests
{
    private static IUserErrorService ErrorService { get; } =
        new UserErrorService(NullLogger<UserErrorService>.Instance);

    [Fact]
    public void TranslationCannotStartWithoutASelection()
    {
        var viewModel = CreateViewModel(new StreamingTranslationService());

        Assert.False(viewModel.CanTranslate);
        Assert.False(viewModel.TranslateCommand.CanExecute(null));
    }

    [Fact]
    public void UserFacingErrorsIncludeStableCodeWithoutTechnicalExceptionText()
    {
        var error = ErrorService.Report(
            UserErrorCode.DocumentOpenFailed,
            new InvalidOperationException("private-path-and-internal-detail"));

        Assert.Equal("PDF_OPEN_FAILED", error.Code);
        Assert.Contains("请确认", error.SuggestedAction);
        Assert.DoesNotContain("private-path-and-internal-detail", error.DialogText);
    }

    [Fact]
    public void SelectingTextDoesNotAutomaticallyCallTheApiService()
    {
        var service = new StreamingTranslationService();
        var viewModel = CreateViewModel(service);

        viewModel.SetSourceText("Selected source");

        Assert.True(viewModel.CanTranslate);
        Assert.Null(service.LastRequest);
        Assert.Contains("点击", viewModel.StatusText);
    }

    [Fact]
    public async Task StreamingChunksAreDisplayedAndRequestUsesSelectedOptions()
    {
        var service = new StreamingTranslationService();
        var viewModel = CreateViewModel(service);
        viewModel.SetSourceText("Selected source");
        viewModel.SelectedPreset = TranslationPreset.ComputerScience;
        viewModel.TargetLanguage = "zh-CN";

        await viewModel.TranslateAsync();

        Assert.Equal("流式译文", viewModel.TranslatedText);
        Assert.Equal(TranslationTaskState.Completed, viewModel.State);
        Assert.Equal("Selected source", service.LastRequest?.SourceText);
        Assert.Equal(TranslationPreset.ComputerScience, service.LastRequest?.Preset);
        Assert.Equal("zh-CN", service.LastRequest?.TargetLanguage);
    }

    [Fact]
    public async Task EditedSourceTextIsUsedWithoutAutomaticTranslation()
    {
        var service = new StreamingTranslationService();
        var viewModel = CreateViewModel(service);
        viewModel.SetSourceText("Journal header\nUseful paragraph\nPage 12");

        viewModel.SourceText = "Useful paragraph";

        Assert.Null(service.LastRequest);
        Assert.Equal("Useful paragraph".Length, viewModel.SourceText.Length);
        await viewModel.TranslateAsync();
        Assert.Equal("Useful paragraph", service.LastRequest?.SourceText);
    }

    [Fact]
    public async Task StopCancelsTheActiveTranslationWithoutRetrying()
    {
        var service = new BlockingTranslationService();
        var viewModel = CreateViewModel(service);
        viewModel.SetSourceText("Selected source");
        var translation = viewModel.TranslateAsync();
        await service.Started.Task.WaitAsync(TimeSpan.FromSeconds(2));

        await viewModel.CancelAsync();
        await translation;

        Assert.Equal(1, service.CancelCount);
        Assert.Equal(TranslationTaskState.Cancelled, viewModel.State);
        Assert.Contains("可能仍会计费", viewModel.StatusText);
    }

    [Fact]
    public async Task EditedTranslationCanBeCopied()
    {
        var clipboard = new RecordingClipboardService();
        var viewModel = CreateViewModel(new StreamingTranslationService(), clipboard);
        viewModel.TranslatedText = "人工修改后的译文";

        await viewModel.CopyTranslationAsync();

        Assert.Equal("人工修改后的译文", clipboard.Text);
    }

    [Fact]
    public async Task BusyClipboardIsRetriedBeforeCopyReportsSuccess()
    {
        var attempts = 0;
        string? copiedText = null;
        var clipboard = new WpfClipboardService(
            text =>
            {
                attempts++;
                if (attempts < 3)
                {
                    throw new COMException("clipboard busy", unchecked((int)0x800401D0));
                }

                copiedText = text;
            },
            (_, _) => Task.CompletedTask);
        var viewModel = CreateViewModel(new StreamingTranslationService(), clipboard);
        viewModel.TranslatedText = "等待剪贴板后复制的译文";

        await viewModel.CopyTranslationAsync();

        Assert.Equal(3, attempts);
        Assert.Equal("等待剪贴板后复制的译文", copiedText);
        Assert.Null(viewModel.ErrorMessage);
        Assert.Contains("复制", viewModel.StatusText);
    }

    [Fact]
    public async Task SavedPresetAndTargetLanguageAreLoaded()
    {
        var settings = new AppSettings
        {
            Translation = new TranslationSettings
            {
                DefaultPreset = "Medical",
                TargetLanguage = "en"
            }
        };
        var viewModel = new TranslationPanelViewModel(
            new StreamingTranslationService(),
            new StubSettingsService(settings),
            new RecordingClipboardService(),
            ErrorService);

        await viewModel.InitializeAsync(CancellationToken.None);

        Assert.Equal(TranslationPreset.Medical, viewModel.SelectedPreset);
        Assert.Equal("en", viewModel.TargetLanguage);
    }

    [Fact]
    public async Task ClassifiedApiErrorIsShownWithoutAutomaticRetry()
    {
        var service = new FailingTranslationService();
        var viewModel = CreateViewModel(service);
        viewModel.SetSourceText("Selected source");

        await viewModel.TranslateAsync();

        Assert.Equal(TranslationTaskState.Failed, viewModel.State);
        Assert.Contains("限流", viewModel.ErrorMessage);
        Assert.Equal(1, service.CallCount);
    }

    [Fact]
    public async Task ClickingPageWhitespaceKeepsSelectionAndEditedTranslationContent()
    {
        var documentId = new DocumentId(Guid.NewGuid());
        var pageText = new PageTextData(
            documentId,
            0,
            "AB",
            new[]
            {
                new TextGlyph(0, "A", new PdfRect(10, 70, 20, 80), 0, 0),
                new TextGlyph(1, "B", new PdfRect(20, 70, 30, 80), 0, 0)
            });
        var readerState = new ReaderState();
        readerState.Open(new PdfDocumentInfo(
            documentId,
            "sample.pdf",
            1,
            IsEncrypted: false,
            HasTextLayer: true,
            Title: null,
            Author: null));
        readerState.SetCurrentPageSize(new PdfSize(100, 100));
        var translation = CreateViewModel(new StreamingTranslationService());
        var reader = new ReaderViewModel(
            new PageTextWorkerClient(pageText),
            readerState,
            new IdentityCoordinateTransformer(),
            new TextSelectionService(),
            translation,
            ErrorService);
        string? selectionError = null;
        reader.ErrorOccurred += (_, args) => selectionError = args.Error.InlineText;
        await reader.BeginSelectionAsync(new ViewPoint(15, 75), CancellationToken.None);
        reader.UpdateSelection(new ViewPoint(25, 75));
        reader.CompleteSelection();
        Assert.True(reader.CurrentSelection is not null, selectionError ?? reader.StatusText);
        translation.SourceText = "人工清理后的原文";
        translation.TranslatedText = "已存在的译文";

        await reader.BeginSelectionAsync(new ViewPoint(100, 100), CancellationToken.None);
        reader.CompleteSelection();

        Assert.NotNull(reader.CurrentSelection);
        Assert.Equal("人工清理后的原文", translation.SourceText);
        Assert.Equal("已存在的译文", translation.TranslatedText);
        Assert.Contains("已保留", reader.StatusText);
    }

    [Fact]
    public async Task ClickingTextWithoutDraggingKeepsExistingTranslationContext()
    {
        var documentId = new DocumentId(Guid.NewGuid());
        var pageText = new PageTextData(
            documentId,
            0,
            "AB",
            new[]
            {
                new TextGlyph(0, "A", new PdfRect(10, 70, 20, 80), 0, 0),
                new TextGlyph(1, "B", new PdfRect(20, 70, 30, 80), 0, 0)
            });
        var readerState = new ReaderState();
        readerState.Open(new PdfDocumentInfo(
            documentId,
            "sample.pdf",
            1,
            IsEncrypted: false,
            HasTextLayer: true,
            Title: null,
            Author: null));
        readerState.SetCurrentPageSize(new PdfSize(100, 100));
        var translation = CreateViewModel(new StreamingTranslationService());
        var reader = new ReaderViewModel(
            new PageTextWorkerClient(pageText),
            readerState,
            new IdentityCoordinateTransformer(),
            new TextSelectionService(),
            translation,
            ErrorService);
        await reader.BeginSelectionAsync(new ViewPoint(15, 75), CancellationToken.None);
        reader.UpdateSelection(new ViewPoint(25, 75));
        reader.CompleteSelection();
        translation.SourceText = "人工清理后的原文";
        translation.TranslatedText = "已存在的译文";
        var existingSelection = reader.CurrentSelection;

        await reader.BeginSelectionAsync(new ViewPoint(25, 75), CancellationToken.None);
        reader.CompleteSelection();

        Assert.Same(existingSelection, reader.CurrentSelection);
        Assert.Equal("人工清理后的原文", translation.SourceText);
        Assert.Equal("已存在的译文", translation.TranslatedText);
        Assert.Contains("未拖动", reader.StatusText);
    }

    [Fact]
    public void WorkerDisconnectDisablesReaderOperationsButKeepsTranslationContent()
    {
        var translation = CreateViewModel(new StreamingTranslationService());
        translation.SourceText = "仍可处理的原文";
        translation.TranslatedText = "仍可复制的译文";
        var readerState = new ReaderState();
        readerState.Open(new PdfDocumentInfo(
            new DocumentId(Guid.NewGuid()),
            "sample.pdf",
            2,
            IsEncrypted: false,
            HasTextLayer: true,
            Title: null,
            Author: null));
        var reader = new ReaderViewModel(
            new PageTextWorkerClient(new PageTextData(
                new DocumentId(Guid.NewGuid()),
                0,
                string.Empty,
                [])),
            readerState,
            new IdentityCoordinateTransformer(),
            new TextSelectionService(),
            translation,
            ErrorService);

        Assert.True(reader.CanUseDocumentControls);
        Assert.True(reader.RotateClockwiseCommand.CanExecute(null));
        Assert.True(reader.GoToPageCommand.CanExecute(null));

        reader.HandleWorkerDisconnected(new PdfWorkerDisconnectedEventArgs(
            PdfWorkerDisconnectReason.ProcessExited,
            exitCode: -1,
            exception: null));

        Assert.False(reader.IsWorkerAvailable);
        Assert.False(reader.CanOpenDocument);
        Assert.False(reader.CanUseDocumentControls);
        Assert.False(reader.RotateClockwiseCommand.CanExecute(null));
        Assert.False(reader.GoToPageCommand.CanExecute(null));
        Assert.Contains("意外停止", reader.StatusText);
        Assert.Equal("仍可处理的原文", translation.SourceText);
        Assert.Equal("仍可复制的译文", translation.TranslatedText);
    }

    [Fact]
    public void RestartedWorkerAllowsOpeningWhenNoDocumentSessionNeedsRecovery()
    {
        var translation = CreateViewModel(new StreamingTranslationService());
        var reader = new ReaderViewModel(
            new PageTextWorkerClient(new PageTextData(
                new DocumentId(Guid.NewGuid()),
                0,
                string.Empty,
                [])),
            new ReaderState(),
            new IdentityCoordinateTransformer(),
            new TextSelectionService(),
            translation,
            ErrorService);
        var disconnect = new PdfWorkerDisconnectedEventArgs(
            PdfWorkerDisconnectReason.ProcessExited,
            exitCode: -1,
            exception: null);

        reader.HandleWorkerDisconnected(disconnect);
        reader.HandleWorkerRestarting();
        reader.HandleWorkerRestarted();

        Assert.True(reader.IsWorkerAvailable);
        Assert.True(reader.CanOpenDocument);
        Assert.Contains("可以打开文档", reader.StatusText);
    }

    private static TranslationPanelViewModel CreateViewModel(
        ITranslationService service,
        IClipboardService? clipboard = null) => new(
            service,
            new StubSettingsService(new AppSettings()),
            clipboard ?? new RecordingClipboardService(),
            ErrorService);

    private sealed class StubSettingsService(AppSettings settings) : ISettingsService
    {
        public Task<AppSettings> LoadAsync(CancellationToken cancellationToken) => Task.FromResult(settings);

        public Task SaveAsync(AppSettings settingsToSave, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class RecordingClipboardService : IClipboardService
    {
        public string? Text { get; private set; }

        public Task SetTextAsync(string text, CancellationToken cancellationToken)
        {
            Text = text;
            return Task.CompletedTask;
        }
    }

    private sealed class StreamingTranslationService : ITranslationService
    {
        public TranslationRequest? LastRequest { get; private set; }

        public async IAsyncEnumerable<TranslationChunk> TranslateAsync(
            TranslationRequest request,
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            LastRequest = request;
            yield return new TranslationChunk(request.RequestId, "流式", IsCompleted: false);
            await Task.Yield();
            cancellationToken.ThrowIfCancellationRequested();
            yield return new TranslationChunk(request.RequestId, "译文", IsCompleted: false);
            yield return new TranslationChunk(request.RequestId, string.Empty, IsCompleted: true);
        }

        public Task CancelAsync(Guid requestId, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class BlockingTranslationService : ITranslationService
    {
        public TaskCompletionSource Started { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);

        public int CancelCount { get; private set; }

        public async IAsyncEnumerable<TranslationChunk> TranslateAsync(
            TranslationRequest request,
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            Started.TrySetResult();
            await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
            yield break;
        }

        public Task CancelAsync(Guid requestId, CancellationToken cancellationToken)
        {
            CancelCount++;
            return Task.CompletedTask;
        }
    }

    private sealed class FailingTranslationService : ITranslationService
    {
        public int CallCount { get; private set; }

        public async IAsyncEnumerable<TranslationChunk> TranslateAsync(
            TranslationRequest request,
            [EnumeratorCancellation] CancellationToken cancellationToken)
        {
            CallCount++;
            await Task.Yield();
            throw new TranslationException(TranslationError.RateLimited, "rate limited");
#pragma warning disable CS0162
            yield break;
#pragma warning restore CS0162
        }

        public Task CancelAsync(Guid requestId, CancellationToken cancellationToken) => Task.CompletedTask;
    }

    private sealed class PageTextWorkerClient(PageTextData pageText) : IPdfWorkerClient
    {
        public event EventHandler<PdfWorkerDisconnectedEventArgs>? Disconnected;

        public Task<PageTextData> GetPageTextAsync(
            DocumentId documentId,
            int pageIndex,
            CancellationToken cancellationToken) => Task.FromResult(pageText);

        public Task StartAsync(CancellationToken cancellationToken) => Task.CompletedTask;

        public Task<PdfDocumentInfo> OpenDocumentAsync(string filePath, string? password, CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public Task CloseDocumentAsync(DocumentId documentId, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task<RenderedPageDescriptor> RenderPageAsync(PageRenderRequest request, CancellationToken cancellationToken) =>
            throw new NotSupportedException();

        public Task<TextHitTestResult?> HitTestTextAsync(
            DocumentId documentId,
            int pageIndex,
            PdfPoint point,
            double tolerance,
            CancellationToken cancellationToken) => Task.FromResult<TextHitTestResult?>(null);

        public Task ReleaseSharedMemoryAsync(string memoryMapName, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task CancelRequestAsync(Guid requestId, CancellationToken cancellationToken) => Task.CompletedTask;

        public Task PingAsync(CancellationToken cancellationToken) => Task.CompletedTask;

        public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

        public ValueTask DisposeAsync() => ValueTask.CompletedTask;

        public void ReportDisconnected(PdfWorkerDisconnectedEventArgs eventArgs) =>
            Disconnected?.Invoke(this, eventArgs);
    }

    private sealed class IdentityCoordinateTransformer : ICoordinateTransformer
    {
        public ViewPoint PdfToView(PdfPoint pdfPoint, PageTransformContext context) =>
            new(pdfPoint.X, pdfPoint.Y);

        public PdfPoint ViewToPdf(ViewPoint viewPoint, PageTransformContext context) =>
            new(viewPoint.X, viewPoint.Y);

        public ViewRect PdfToView(PdfRect pdfRect, PageTransformContext context) =>
            new(pdfRect.Left, pdfRect.Bottom, pdfRect.Right - pdfRect.Left, pdfRect.Top - pdfRect.Bottom);
    }
}
