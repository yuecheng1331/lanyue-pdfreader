using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Input;
using LocalPdfReader.App.Commands;
using LocalPdfReader.Application.Configuration;
using LocalPdfReader.Application.Translation;
using LocalPdfReader.Domain;

namespace LocalPdfReader.App;

public sealed class TranslationPanelViewModel : INotifyPropertyChanged
{
    private static readonly TimeSpan StreamingUiUpdateInterval = TimeSpan.FromMilliseconds(50);

    private readonly ITranslationService _translationService;
    private readonly ISettingsService _settingsService;
    private readonly IClipboardService _clipboardService;
    private readonly IUserErrorService _userErrorService;
    private readonly AsyncCommand[] _commands;
    private string _sourceText = string.Empty;
    private string _translatedText = string.Empty;
    private TranslationPreset _selectedPreset = TranslationPreset.Academic;
    private string _targetLanguage = "zh-CN";
    private string _customInstruction = string.Empty;
    private TranslationTaskState _state = TranslationTaskState.Idle;
    private string _statusText = "请先在 PDF 页面中选择文字。";
    private string? _errorMessage;
    private Guid? _activeRequestId;
    private CancellationTokenSource? _translationCancellationSource;
    private bool _hasAttemptedTranslation;

    public TranslationPanelViewModel(
        ITranslationService translationService,
        ISettingsService settingsService,
        IClipboardService clipboardService,
        IUserErrorService userErrorService)
    {
        _translationService = translationService;
        _settingsService = settingsService;
        _clipboardService = clipboardService;
        _userErrorService = userErrorService;

        TranslateCommand = new AsyncCommand(TranslateAsync, () => CanTranslate);
        CancelTranslationCommand = new AsyncCommand(CancelAsync, () => CanCancel);
        RetryTranslationCommand = new AsyncCommand(TranslateAsync, () => CanRetry);
        CopyTranslationCommand = new AsyncCommand(CopyTranslationAsync, () => CanCopyTranslation);
        _commands =
        [
            (AsyncCommand)TranslateCommand,
            (AsyncCommand)CancelTranslationCommand,
            (AsyncCommand)RetryTranslationCommand,
            (AsyncCommand)CopyTranslationCommand
        ];
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public ICommand TranslateCommand { get; }

    public ICommand CancelTranslationCommand { get; }

    public ICommand RetryTranslationCommand { get; }

    public ICommand CopyTranslationCommand { get; }

    public IReadOnlyList<TranslationPresetOption> PresetOptions { get; } =
    [
        new(TranslationPreset.Literal, "直译"),
        new(TranslationPreset.Fluent, "流畅"),
        new(TranslationPreset.Academic, "学术论文"),
        new(TranslationPreset.ComputerScience, "计算机科学"),
        new(TranslationPreset.Medical, "医学"),
        new(TranslationPreset.Custom, "自定义")
    ];

    public IReadOnlyList<TargetLanguageOption> TargetLanguageOptions { get; } =
    [
        new("zh-CN", "简体中文"),
        new("zh-TW", "繁体中文"),
        new("en", "英语"),
        new("ja", "日语"),
        new("ko", "韩语"),
        new("de", "德语"),
        new("fr", "法语")
    ];

    public string SourceText
    {
        get => _sourceText;
        set => UpdateSourceText(value ?? string.Empty);
    }

    public string SourceCharacterCountText => SourceText.Length == 0
        ? "尚未选择原文"
        : $"将发送 {SourceText.Length} 个字符（点击翻译后才会联网）";

    public string TranslatedText
    {
        get => _translatedText;
        set
        {
            if (SetProperty(ref _translatedText, value))
            {
                NotifyCommandStateChanged();
            }
        }
    }

    public TranslationPreset SelectedPreset
    {
        get => _selectedPreset;
        set
        {
            if (SetProperty(ref _selectedPreset, value))
            {
                OnPropertyChanged(nameof(IsCustomPreset));
                NotifyCommandStateChanged();
            }
        }
    }

    public string TargetLanguage
    {
        get => _targetLanguage;
        set
        {
            if (SetProperty(ref _targetLanguage, value))
            {
                NotifyCommandStateChanged();
            }
        }
    }

    public string CustomInstruction
    {
        get => _customInstruction;
        set
        {
            if (SetProperty(ref _customInstruction, value))
            {
                NotifyCommandStateChanged();
            }
        }
    }

    public bool IsCustomPreset => SelectedPreset == TranslationPreset.Custom;

    public TranslationTaskState State
    {
        get => _state;
        private set
        {
            if (SetProperty(ref _state, value))
            {
                OnPropertyChanged(nameof(IsTranslating));
                NotifyCommandStateChanged();
            }
        }
    }

    public bool IsTranslating => State == TranslationTaskState.Translating;

    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }

    public string? ErrorMessage
    {
        get => _errorMessage;
        private set => SetProperty(ref _errorMessage, value);
    }

    public bool CanTranslate =>
        !IsTranslating
        && !string.IsNullOrWhiteSpace(SourceText)
        && !string.IsNullOrWhiteSpace(TargetLanguage)
        && (!IsCustomPreset || !string.IsNullOrWhiteSpace(CustomInstruction));

    public bool CanCancel => IsTranslating;

    public bool CanRetry => CanTranslate && _hasAttemptedTranslation;

    public bool CanCopyTranslation => !string.IsNullOrWhiteSpace(TranslatedText);

    public async Task InitializeAsync(CancellationToken cancellationToken)
    {
        try
        {
            var settings = await _settingsService.LoadAsync(cancellationToken);
            TargetLanguage = settings.Translation.TargetLanguage;
            SelectedPreset = Enum.TryParse<TranslationPreset>(
                settings.Translation.DefaultPreset,
                ignoreCase: true,
                out var preset)
                ? preset
                : TranslationPreset.Academic;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
        }
        catch (Exception exception)
        {
            ErrorMessage = _userErrorService.Report(
                UserErrorCode.TranslationSettingsReadFailed,
                exception).InlineText;
            StatusText = "翻译设置加载失败。";
        }
    }

    public void SetSourceText(string sourceText)
    {
        UpdateSourceText(sourceText ?? string.Empty);
    }

    private void UpdateSourceText(string sourceText)
    {
        if (string.Equals(SourceText, sourceText, StringComparison.Ordinal))
        {
            return;
        }

        StopCurrentRequestForSourceChange();
        SetProperty(ref _sourceText, sourceText, nameof(SourceText));
        OnPropertyChanged(nameof(SourceCharacterCountText));
        TranslatedText = string.Empty;
        ErrorMessage = null;
        _hasAttemptedTranslation = false;
        State = sourceText.Length == 0 ? TranslationTaskState.Idle : TranslationTaskState.Ready;
        StatusText = sourceText.Length == 0
            ? "请先在 PDF 页面中选择文字。"
            : "原文可在发送前编辑；只有点击“开始翻译”才会调用 API。";
        NotifyCommandStateChanged();
    }

    public async Task TranslateAsync()
    {
        if (!CanTranslate)
        {
            return;
        }

        var requestId = Guid.NewGuid();
        var sourceSnapshot = SourceText;
        using var cancellationSource = new CancellationTokenSource();
        _translationCancellationSource = cancellationSource;
        _activeRequestId = requestId;
        _hasAttemptedTranslation = true;
        TranslatedText = string.Empty;
        ErrorMessage = null;
        State = TranslationTaskState.Translating;
        StatusText = "正在翻译；此请求已经开始使用 API。";
        var pendingText = new StringBuilder();
        var lastUiUpdate = DateTime.UtcNow;

        try
        {
            var request = new TranslationRequest(
                requestId,
                sourceSnapshot,
                TargetLanguage,
                SelectedPreset,
                SourceLanguage: null,
                CustomInstruction: IsCustomPreset ? CustomInstruction.Trim() : null);

            await foreach (var chunk in _translationService.TranslateAsync(request, cancellationSource.Token))
            {
                if (!IsCurrentRequest(requestId) || chunk.RequestId != requestId)
                {
                    continue;
                }

                pendingText.Append(chunk.Text);
                if (chunk.IsCompleted || DateTime.UtcNow - lastUiUpdate >= StreamingUiUpdateInterval)
                {
                    FlushPendingText(pendingText);
                    lastUiUpdate = DateTime.UtcNow;
                }
            }

            if (IsCurrentRequest(requestId))
            {
                FlushPendingText(pendingText);
                State = TranslationTaskState.Completed;
                StatusText = "翻译完成。你可以编辑或复制译文。";
            }
        }
        catch (OperationCanceledException) when (cancellationSource.IsCancellationRequested)
        {
            if (IsCurrentRequest(requestId))
            {
                FlushPendingText(pendingText);
                State = TranslationTaskState.Cancelled;
                StatusText = "翻译已停止；停止前已经生成的内容可能仍会计费。";
            }
        }
        catch (TranslationException exception)
        {
            if (IsCurrentRequest(requestId))
            {
                FlushPendingText(pendingText);
                State = TranslationTaskState.Failed;
                ErrorMessage = _userErrorService.Report(GetErrorCode(exception.Error), exception).InlineText;
                StatusText = "翻译失败，未自动重试。";
            }
        }
        catch (Exception exception)
        {
            if (IsCurrentRequest(requestId))
            {
                FlushPendingText(pendingText);
                State = TranslationTaskState.Failed;
                ErrorMessage = _userErrorService.Report(
                    UserErrorCode.TranslationUnexpectedFailure,
                    exception).InlineText;
                StatusText = "翻译失败，未自动重试。";
            }
        }
        finally
        {
            if (IsCurrentRequest(requestId))
            {
                _activeRequestId = null;
                _translationCancellationSource = null;
                NotifyCommandStateChanged();
            }
        }
    }

    public async Task CancelAsync()
    {
        if (_activeRequestId is not { } requestId || _translationCancellationSource is not { } cancellationSource)
        {
            return;
        }

        StatusText = "正在停止翻译…";
        cancellationSource.Cancel();
        await _translationService.CancelAsync(requestId, CancellationToken.None);
    }

    public async Task CopyTranslationAsync()
    {
        if (!CanCopyTranslation)
        {
            return;
        }

        try
        {
            await _clipboardService.SetTextAsync(TranslatedText, CancellationToken.None);
            StatusText = "译文已复制到剪贴板。";
            ErrorMessage = null;
        }
        catch (Exception exception)
        {
            ErrorMessage = _userErrorService.Report(UserErrorCode.ClipboardWriteFailed, exception).InlineText;
        }
    }

    private void StopCurrentRequestForSourceChange()
    {
        _translationCancellationSource?.Cancel();
        _translationCancellationSource = null;
        _activeRequestId = null;
    }

    private bool IsCurrentRequest(Guid requestId) => _activeRequestId == requestId;

    private void FlushPendingText(StringBuilder pendingText)
    {
        if (pendingText.Length == 0)
        {
            return;
        }

        TranslatedText += pendingText.ToString();
        pendingText.Clear();
    }

    private static UserErrorCode GetErrorCode(TranslationError error) => error switch
    {
        TranslationError.AuthenticationFailed => UserErrorCode.TranslationAuthenticationFailed,
        TranslationError.RateLimited => UserErrorCode.TranslationRateLimited,
        TranslationError.Timeout => UserErrorCode.TranslationTimeout,
        TranslationError.NetworkUnavailable => UserErrorCode.TranslationNetworkUnavailable,
        TranslationError.NetworkAccessDisabled => UserErrorCode.TranslationNetworkDisabled,
        TranslationError.MissingCredential => UserErrorCode.TranslationCredentialMissing,
        TranslationError.InvalidResponse => UserErrorCode.TranslationInvalidResponse,
        _ => UserErrorCode.TranslationUnexpectedFailure
    };

    private bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }

        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    private void NotifyCommandStateChanged()
    {
        OnPropertyChanged(nameof(CanTranslate));
        OnPropertyChanged(nameof(CanCancel));
        OnPropertyChanged(nameof(CanRetry));
        OnPropertyChanged(nameof(CanCopyTranslation));
        foreach (var command in _commands)
        {
            command.RaiseCanExecuteChanged();
        }
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

public enum TranslationTaskState
{
    Idle,
    Ready,
    Translating,
    Completed,
    Cancelled,
    Failed
}

public sealed record TranslationPresetOption(TranslationPreset Value, string Label);

public sealed record TargetLanguageOption(string Value, string Label);
