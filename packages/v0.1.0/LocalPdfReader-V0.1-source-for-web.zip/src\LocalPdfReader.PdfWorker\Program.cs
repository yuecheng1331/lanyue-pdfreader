using System.IO.Pipes;
using LocalPdfReader.Domain;
using LocalPdfReader.PdfProtocol;
using LocalPdfReader.PdfWorker;

var pipeName = GetPipeName(args);

if (pipeName is null)
{
    Console.Error.WriteLine("Missing required --pipe-name argument.");
    return 1;
}

await using var pipe = new NamedPipeServerStream(
    pipeName,
    PipeDirection.InOut,
    maxNumberOfServerInstances: 1,
    PipeTransmissionMode.Byte,
    PipeOptions.Asynchronous);

await pipe.WaitForConnectionAsync();

var handshakeRequest = await PipeMessageSerializer.ReadAsync(pipe, CancellationToken.None);
var isAccepted = handshakeRequest.MessageType == PipeMessageTypes.HandshakeRequest &&
    handshakeRequest.ProtocolVersion == PdfWorkerProtocol.CurrentVersion;
await WriteResponseAsync(pipe, handshakeRequest, PipeMessageTypes.HandshakeResponse, null,
    new HandshakeResponse(isAccepted, PdfWorkerProtocol.CurrentVersion));

if (!isAccepted)
{
    return 2;
}

using var documents = new WorkerDocumentService(new PdfiumNativeAdapter());

while (pipe.IsConnected)
{
    PipeMessageEnvelope request;

    try
    {
        request = await PipeMessageSerializer.ReadAsync(pipe, CancellationToken.None);
    }
    catch (EndOfStreamException)
    {
        break;
    }

    try
    {
        switch (request.MessageType)
        {
            case PipeMessageTypes.CancelRequest:
            {
                var cancellationRequest = PipeMessageSerializer.DeserializePayload<CancelRequest>(request.Payload);
                await WriteResponseAsync(pipe, request, PipeMessageTypes.CancelResponse, null,
                    new CancelResponse(cancellationRequest.TargetRequestId, WasCanceled: false));
                break;
            }

            case PipeMessageTypes.PingRequest:
                await WriteResponseAsync(pipe, request, PipeMessageTypes.PingResponse, null, new PingResponse());
                break;

            case PipeMessageTypes.OpenDocumentRequest:
            {
                var openRequest = PipeMessageSerializer.DeserializePayload<OpenDocumentRequest>(request.Payload);
                var info = documents.Open(openRequest.FilePath, openRequest.Password);
                await WriteResponseAsync(pipe, request, PipeMessageTypes.OpenDocumentResponse, info.DocumentId,
                    new OpenDocumentResponse(info));
                break;
            }

            case PipeMessageTypes.CloseDocumentRequest:
            {
                var documentId = RequireDocumentId(request);
                documents.Close(documentId);
                await WriteResponseAsync(pipe, request, PipeMessageTypes.CloseDocumentResponse, documentId, new CloseDocumentResponse());
                break;
            }

            case PipeMessageTypes.RenderPageRequest:
            {
                var renderRequest = PipeMessageSerializer.DeserializePayload<RenderPageRequest>(request.Payload).RenderRequest;
                if (request.DocumentId != renderRequest.DocumentId)
                {
                    throw new InvalidDataException("The render request document identifier does not match its envelope.");
                }

                var descriptor = documents.Render(renderRequest);
                await WriteResponseAsync(pipe, request, PipeMessageTypes.RenderPageResponse, renderRequest.DocumentId,
                    new RenderPageResponse(descriptor));
                break;
            }

            case PipeMessageTypes.GetPageTextRequest:
            {
                var documentId = RequireDocumentId(request);
                var textRequest = PipeMessageSerializer.DeserializePayload<GetPageTextRequest>(request.Payload);
                var pageText = documents.GetPageText(documentId, textRequest.PageIndex);
                await WriteResponseAsync(pipe, request, PipeMessageTypes.GetPageTextResponse, documentId,
                    new GetPageTextResponse(pageText));
                break;
            }

            case PipeMessageTypes.HitTestTextRequest:
            {
                var documentId = RequireDocumentId(request);
                var hitRequest = PipeMessageSerializer.DeserializePayload<HitTestTextRequest>(request.Payload);
                var hit = documents.HitTestText(documentId, hitRequest.PageIndex, hitRequest.Point, hitRequest.Tolerance);
                await WriteResponseAsync(pipe, request, PipeMessageTypes.HitTestTextResponse, documentId,
                    new HitTestTextResponse(hit));
                break;
            }

            case PipeMessageTypes.ReleaseSharedMemoryRequest:
            {
                var releaseRequest = PipeMessageSerializer.DeserializePayload<ReleaseSharedMemoryRequest>(request.Payload);
                var wasReleased = documents.ReleaseSharedMemory(releaseRequest.MemoryMapName);
                await WriteResponseAsync(pipe, request, PipeMessageTypes.ReleaseSharedMemoryResponse, null,
                    new ReleaseSharedMemoryResponse(wasReleased));
                break;
            }

            default:
                throw new InvalidDataException($"Unsupported PDF worker message type {request.MessageType}.");
        }
    }
    catch (Exception exception) when (exception is not OperationCanceledException)
    {
        await WriteResponseAsync(pipe, request, PipeMessageTypes.ErrorResponse, request.DocumentId,
            new ErrorResponse("PdfWorkerRequestFailed", exception.Message));
    }
}

return 0;

static async Task WriteResponseAsync<TPayload>(
    Stream stream,
    PipeMessageEnvelope request,
    string messageType,
    DocumentId? documentId,
    TPayload payload)
{
    var response = new PipeMessageEnvelope(
        PdfWorkerProtocol.CurrentVersion,
        messageType,
        request.RequestId,
        documentId,
        PipeMessageSerializer.SerializePayload(payload));
    await PipeMessageSerializer.WriteAsync(stream, response, CancellationToken.None);
    await stream.FlushAsync();
}

static DocumentId RequireDocumentId(PipeMessageEnvelope request) =>
    request.DocumentId ?? throw new InvalidDataException("The request does not include a document identifier.");

static string? GetPipeName(string[] arguments)
{
    for (var index = 0; index < arguments.Length - 1; index++)
    {
        if (string.Equals(arguments[index], "--pipe-name", StringComparison.Ordinal))
        {
            return arguments[index + 1];
        }
    }

    return null;
}
