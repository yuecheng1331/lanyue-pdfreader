using System.Runtime.InteropServices;
using LocalPdfReader.Domain;
using PDFiumCore;

namespace LocalPdfReader.PdfWorker;

internal interface IPdfNativeAdapter : IDisposable
{
    NativePdfDocument Open(string filePath, string? password);

    void Close(NativePdfDocument document);

    NativePdfDocumentInfo GetDocumentInfo(NativePdfDocument document, DocumentId documentId, string fileName);

    NativeRenderedPage RenderPage(NativePdfDocument document, PageRenderRequest request);

    PageTextData ExtractPageText(NativePdfDocument document, DocumentId documentId, int pageIndex);

    TextHitTestResult? HitTestText(NativePdfDocument document, int pageIndex, PdfPoint point, double tolerance);
}

internal sealed class NativePdfDocument(FpdfDocumentT handle, string filePath)
{
    public FpdfDocumentT Handle { get; } = handle;

    public string FilePath { get; } = filePath;
}

internal sealed record NativePdfDocumentInfo(PdfDocumentInfo DocumentInfo);

internal sealed record NativeRenderedPage(
    byte[] Pixels,
    int PixelWidth,
    int PixelHeight,
    int Stride,
    PdfSize OriginalPageSize);

internal sealed class PdfiumNativeAdapter : IPdfNativeAdapter
{
    private bool _disposed;

    public PdfiumNativeAdapter()
    {
        fpdfview.FPDF_InitLibrary();
    }

    public NativePdfDocument Open(string filePath, string? password)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        var document = fpdfview.FPDF_LoadDocument(filePath, password);
        if (document == null)
        {
            throw new InvalidOperationException($"PDFium could not open the document (error {fpdfview.FPDF_GetLastError()}).");
        }

        return new NativePdfDocument(document, filePath);
    }

    public void Close(NativePdfDocument document)
    {
        ArgumentNullException.ThrowIfNull(document);
        fpdfview.FPDF_CloseDocument(document.Handle);
    }

    public NativePdfDocumentInfo GetDocumentInfo(NativePdfDocument document, DocumentId documentId, string fileName)
    {
        ArgumentNullException.ThrowIfNull(document);

        var pageCount = fpdfview.FPDF_GetPageCount(document.Handle);
        var hasTextLayer = pageCount > 0 && PageHasText(document.FilePath);
        return new NativePdfDocumentInfo(new PdfDocumentInfo(
            documentId,
            fileName,
            pageCount,
            IsEncrypted: false,
            hasTextLayer,
            Title: GetMetadata(document.Handle, "Title"),
            Author: GetMetadata(document.Handle, "Author")));
    }

    public NativeRenderedPage RenderPage(NativePdfDocument document, PageRenderRequest request)
    {
        ArgumentNullException.ThrowIfNull(document);

        var page = fpdfview.FPDF_LoadPage(document.Handle, request.PageIndex);
        if (page == null)
        {
            throw new InvalidOperationException($"PDFium could not load page {request.PageIndex} (error {fpdfview.FPDF_GetLastError()}).");
        }

        FpdfBitmapT? bitmap = null;
        try
        {
            double pageWidth = 0;
            double pageHeight = 0;
            if (fpdfview.FPDF_GetPageSizeByIndex(document.Handle, request.PageIndex, ref pageWidth, ref pageHeight) == 0)
            {
                throw new InvalidOperationException("PDFium could not obtain the page size.");
            }

            var originalSize = new PdfSize(pageWidth, pageHeight);
            var scale = request.ZoomFactor * 96d / 72d;
            var unrotatedWidth = CheckedPixelLength(pageWidth * scale * request.DpiScaleX);
            var unrotatedHeight = CheckedPixelLength(pageHeight * scale * request.DpiScaleY);
            var isQuarterTurn = request.Rotation is PageRotation.Rotate90 or PageRotation.Rotate270;
            var pixelWidth = isQuarterTurn ? unrotatedHeight : unrotatedWidth;
            var pixelHeight = isQuarterTurn ? unrotatedWidth : unrotatedHeight;
            bitmap = fpdfview.FPDFBitmapCreateEx(pixelWidth, pixelHeight, (int)FPDFBitmapFormat.BGRA, IntPtr.Zero, 0);
            if (bitmap == null)
            {
                throw new InvalidOperationException("PDFium could not allocate a bitmap for the page.");
            }

            fpdfview.FPDFBitmapFillRect(bitmap, 0, 0, pixelWidth, pixelHeight, 0xFFFFFFFF);
            fpdfview.FPDF_RenderPageBitmap(
                bitmap,
                page,
                0,
                0,
                pixelWidth,
                pixelHeight,
                ToPdfiumRotation(request.Rotation),
                (int)RenderFlags.RenderAnnotations);

            var stride = fpdfview.FPDFBitmapGetStride(bitmap);
            var pixels = new byte[checked(stride * pixelHeight)];
            Marshal.Copy(fpdfview.FPDFBitmapGetBuffer(bitmap), pixels, 0, pixels.Length);
            return new NativeRenderedPage(pixels, pixelWidth, pixelHeight, stride, originalSize);
        }
        finally
        {
            if (bitmap is not null)
            {
                fpdfview.FPDFBitmapDestroy(bitmap);
            }

            fpdfview.FPDF_ClosePage(page);
        }
    }

    public PageTextData ExtractPageText(NativePdfDocument document, DocumentId documentId, int pageIndex)
    {
        ArgumentNullException.ThrowIfNull(document);
        var page = fpdfview.FPDF_LoadPage(document.Handle, pageIndex);
        if (page == null)
        {
            throw new InvalidOperationException($"PDFium could not load page {pageIndex} for text extraction.");
        }

        var textPage = fpdf_text.FPDFTextLoadPage(page);
        if (textPage == null)
        {
            fpdfview.FPDF_ClosePage(page);
            throw new InvalidOperationException("PDFium could not load the page text layer.");
        }

        try
        {
            var characterCount = fpdf_text.FPDFTextCountChars(textPage);
            if (characterCount < 0)
            {
                throw new InvalidOperationException("PDFium could not count page characters.");
            }

            var rawText = new System.Text.StringBuilder(characterCount);
            var glyphs = new List<TextGlyph>(characterCount);
            var lineIndex = 0;
            double? previousLineCenter = null;
            double previousLineHeight = 0;

            for (var index = 0; index < characterCount; index++)
            {
                var text = ToUnicodeText(fpdf_text.FPDFTextGetUnicode(textPage, index));
                if (text.Length == 0)
                {
                    continue;
                }

                rawText.Append(text);
                double left = 0;
                double right = 0;
                double bottom = 0;
                double top = 0;
                var hasBox = fpdf_text.FPDFTextGetCharBox(textPage, index, ref left, ref right, ref bottom, ref top) != 0;
                var bounds = hasBox
                    ? new PdfRect(left, bottom, right, top)
                    : new PdfRect(0, 0, 0, 0);

                if (text is "\r" or "\n")
                {
                    lineIndex++;
                    previousLineCenter = null;
                    previousLineHeight = 0;
                }
                else if (hasBox)
                {
                    var center = (bottom + top) / 2;
                    var height = Math.Max(0.1, top - bottom);
                    if (previousLineCenter is { } previousCenter &&
                        Math.Abs(center - previousCenter) > Math.Max(previousLineHeight, height) * 0.6)
                    {
                        lineIndex++;
                    }

                    previousLineCenter = center;
                    previousLineHeight = height;
                }

                glyphs.Add(new TextGlyph(index, text, bounds, lineIndex, BlockIndex: 0));
            }

            return new PageTextData(documentId, pageIndex, rawText.ToString(), glyphs);
        }
        finally
        {
            // The text page borrows the PDF page; release it first, then release the page handle.
            fpdf_text.FPDFTextClosePage(textPage);
            fpdfview.FPDF_ClosePage(page);
        }
    }

    public TextHitTestResult? HitTestText(
        NativePdfDocument document,
        int pageIndex,
        PdfPoint point,
        double tolerance)
    {
        ArgumentNullException.ThrowIfNull(document);
        var page = fpdfview.FPDF_LoadPage(document.Handle, pageIndex);
        if (page == null)
        {
            throw new InvalidOperationException($"PDFium could not load page {pageIndex} for text hit testing.");
        }

        var textPage = fpdf_text.FPDFTextLoadPage(page);
        if (textPage == null)
        {
            fpdfview.FPDF_ClosePage(page);
            throw new InvalidOperationException("PDFium could not load the page text layer.");
        }

        try
        {
            var index = fpdf_text.FPDFTextGetCharIndexAtPos(textPage, point.X, point.Y, tolerance, tolerance);
            if (index < 0)
            {
                return null;
            }

            double left = 0;
            double right = 0;
            double bottom = 0;
            double top = 0;
            if (fpdf_text.FPDFTextGetCharBox(textPage, index, ref left, ref right, ref bottom, ref top) == 0)
            {
                return null;
            }

            return new TextHitTestResult(
                index,
                ToUnicodeText(fpdf_text.FPDFTextGetUnicode(textPage, index)),
                new PdfRect(left, bottom, right, top));
        }
        finally
        {
            fpdf_text.FPDFTextClosePage(textPage);
            fpdfview.FPDF_ClosePage(page);
        }
    }

    private static string ToUnicodeText(uint codePoint)
    {
        if (codePoint == 0 || codePoint > 0x10FFFF || codePoint is >= 0xD800 and <= 0xDFFF)
        {
            return string.Empty;
        }

        return char.ConvertFromUtf32((int)codePoint);
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        fpdfview.FPDF_DestroyLibrary();
    }

    private static int CheckedPixelLength(double value)
    {
        if (double.IsNaN(value) || double.IsInfinity(value) || value <= 0 || value > 16_384)
        {
            throw new ArgumentOutOfRangeException(nameof(value), "The requested page dimensions are outside the supported range.");
        }

        return checked((int)Math.Ceiling(value));
    }

    private static int ToPdfiumRotation(PageRotation rotation) => rotation switch
    {
        PageRotation.Rotate0 => 0,
        PageRotation.Rotate90 => 1,
        PageRotation.Rotate180 => 2,
        PageRotation.Rotate270 => 3,
        _ => throw new ArgumentOutOfRangeException(nameof(rotation))
    };

    private static string? GetMetadata(FpdfDocumentT document, string tag)
    {
        var byteLength = fpdf_doc.FPDF_GetMetaText(document, tag, IntPtr.Zero, 0);
        if (byteLength <= sizeof(char))
        {
            return null;
        }

        var buffer = Marshal.AllocHGlobal(checked((int)byteLength));
        try
        {
            _ = fpdf_doc.FPDF_GetMetaText(document, tag, buffer, byteLength);
            return Marshal.PtrToStringUni(buffer);
        }
        finally
        {
            Marshal.FreeHGlobal(buffer);
        }
    }

    private static bool PageHasText(string filePath)
    {
        // PDFiumCore's current low-level package does not expose FPDFText_*.
        // For C-stage metadata, conservatively detect an embedded font declaration;
        // full page text extraction is deliberately owned by the later text service.
        var pdfBytes = File.ReadAllBytes(filePath);
        return pdfBytes.AsSpan().IndexOf("/Font"u8) >= 0;
    }
}
