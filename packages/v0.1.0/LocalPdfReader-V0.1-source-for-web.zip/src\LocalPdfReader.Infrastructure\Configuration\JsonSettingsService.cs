using System.Text.Json;
using LocalPdfReader.Application.Configuration;
using Microsoft.Extensions.Logging;

namespace LocalPdfReader.Infrastructure.Configuration;

public sealed class JsonSettingsService(string settingsFilePath, ILogger<JsonSettingsService> logger) : ISettingsService
{
    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    public async Task<AppSettings> LoadAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (!File.Exists(settingsFilePath))
        {
            var defaults = new AppSettings();
            await SaveAsync(defaults, cancellationToken);
            logger.LogInformation(new EventId(2000, "SettingsCreated"), "Created default settings file.");
            return defaults;
        }

        await using var stream = File.OpenRead(settingsFilePath);
        var settings = await JsonSerializer.DeserializeAsync<AppSettings>(stream, SerializerOptions, cancellationToken);

        if (settings is not null)
        {
            logger.LogInformation(new EventId(2001, "SettingsLoaded"), "Loaded application settings.");
            return settings;
        }

        throw new InvalidDataException("The settings file does not contain a valid settings object.");
    }

    public async Task SaveAsync(AppSettings settings, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(settings);
        cancellationToken.ThrowIfCancellationRequested();

        var directoryPath = Path.GetDirectoryName(settingsFilePath)
            ?? throw new InvalidOperationException("The settings file path must include a directory.");
        Directory.CreateDirectory(directoryPath);

        var temporaryFilePath = $"{settingsFilePath}.{Guid.NewGuid():N}.tmp";

        try
        {
            await using (var stream = File.Create(temporaryFilePath))
            {
                await JsonSerializer.SerializeAsync(stream, settings, SerializerOptions, cancellationToken);
            }

            File.Move(temporaryFilePath, settingsFilePath, overwrite: true);
            logger.LogInformation(new EventId(2002, "SettingsSaved"), "Saved application settings.");
        }
        finally
        {
            if (File.Exists(temporaryFilePath))
            {
                File.Delete(temporaryFilePath);
            }
        }
    }
}
