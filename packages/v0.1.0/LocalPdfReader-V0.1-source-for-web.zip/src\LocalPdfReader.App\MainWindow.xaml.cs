using System.Windows;
using System.Windows.Input;
using LocalPdfReader.Domain;
using Microsoft.Win32;

namespace LocalPdfReader.App;

public partial class MainWindow : Window
{
    private readonly ReaderViewModel _viewModel;
    private readonly SettingsViewModel _settingsViewModel;

    public MainWindow(ReaderViewModel viewModel, SettingsViewModel settingsViewModel)
    {
        _viewModel = viewModel;
        _settingsViewModel = settingsViewModel;
        InitializeComponent();
        DataContext = viewModel;
        _viewModel.ErrorOccurred += OnReaderErrorOccurred;
    }

    protected override void OnClosed(EventArgs e)
    {
        _viewModel.ErrorOccurred -= OnReaderErrorOccurred;
        base.OnClosed(e);
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e) =>
        await _viewModel.Translation.InitializeAsync(CancellationToken.None);

    private async void OpenButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "PDF 文件 (*.pdf)|*.pdf",
            CheckFileExists = true,
            Multiselect = false
        };

        if (dialog.ShowDialog(this) == true)
        {
            await _viewModel.OpenDocumentAsync(dialog.FileName, CancellationToken.None);
        }
    }

    private void OnReaderErrorOccurred(object? sender, ReaderErrorEventArgs e) =>
        MessageBox.Show(this, e.Error.DialogText, e.Error.Title, MessageBoxButton.OK, MessageBoxImage.Error);

    private async void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var window = new SettingsWindow(_settingsViewModel) { Owner = this };
        window.ShowDialog();
        await _viewModel.Translation.InitializeAsync(CancellationToken.None);
    }

    private void PageNumberTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e) =>
        e.Handled = e.Text.Any(character => !char.IsAsciiDigit(character));

    private void PageNumberTextBox_Pasting(object sender, DataObjectPastingEventArgs e)
    {
        if (!e.SourceDataObject.GetDataPresent(DataFormats.UnicodeText) ||
            e.SourceDataObject.GetData(DataFormats.UnicodeText) is not string text ||
            text.Any(character => !char.IsAsciiDigit(character)))
        {
            e.CancelCommand();
        }
    }

    private void PdfViewport_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        const double pageMargin = 48;
        _viewModel.UpdateViewportSize(
            Math.Max(0, e.NewSize.Width - pageMargin),
            Math.Max(0, e.NewSize.Height - pageMargin));
    }

    private async void PageSurface_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        PageSurface.CaptureMouse();
        var point = e.GetPosition(PageSurface);
        await _viewModel.BeginSelectionAsync(new ViewPoint(point.X, point.Y), CancellationToken.None);
    }

    private void PageSurface_MouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed)
        {
            return;
        }

        var point = e.GetPosition(PageSurface);
        _viewModel.UpdateSelection(new ViewPoint(point.X, point.Y));
    }

    private void PageSurface_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        _viewModel.CompleteSelection();
        PageSurface.ReleaseMouseCapture();
    }
}
